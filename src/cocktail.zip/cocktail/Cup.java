/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cocktail;

/**
 *
 * @author ibrah
 */
class Cup {
    protected float capacity;
    private float contentVolume = 0;
    private int contentCalories = 0;

    public Cup(float capacity) {
        this.capacity = capacity;
    }

    public void fill(float volume, int calories) {
        this.contentVolume = volume;
        this.contentCalories = calories;
    }

    public String getInfo() {
        return "Cup: Capacity " + capacity + "ml, Content Calories: " + contentCalories;
    }
}

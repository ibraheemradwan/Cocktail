/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cocktail;

/**
 *
 * @author ibrah
 */
class Blender {
    private float capacity;
    private float currentVolume = 0;
    private String currentColor = "0,0,0";
    private int totalCalories = 0;

    public Blender(float capacity) {
        this.capacity = capacity;
    }

    public void addIngredient(Ingredients ingredient) throws Exception {
        if (currentVolume + ingredient.volume > capacity) {
            throw new Exception("Blender capacity exceeded");
        }
        currentVolume += ingredient.volume;
        totalCalories += ingredient.calories;
        
        this.currentColor = ingredient.colorRGB; 
    }

    public void blend() {
       
    }

    public String pour(Cup cup) throws Exception {
        if (currentVolume == 0) {
            throw new Exception("Blender is empty");
        }
        if (cup.capacity >= currentVolume) {
            cup.fill(currentVolume, totalCalories);
            currentVolume = 0;
            return "Cocktail poured into cup.";
        } else {
            return "Cup capacity is too small to hold the cocktail.";
        }
    }

    public String getInfo() {
        return "Blender: Capacity " + capacity + "ml, Current Volume " + currentVolume +
               "ml, Current Color: RGB(" + currentColor + "), Total Calories: " + totalCalories;
    }
}

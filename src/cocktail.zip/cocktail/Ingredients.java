/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cocktail;

/**
 *
 * @author ibrah
 */
public  class Ingredients {
    protected String name;
    protected int calories;
    protected float volume;
    protected String colorRGB;

    public Ingredients(String name, int calories, float volume, String colorRGB) {
        this.name = name;
        this.calories = calories;
        this.volume = volume;
        this.colorRGB = colorRGB;
    }

    public String getInfo() {
        return "Ingredient: " + name + ", Calories: " + calories + ", Volume: " + volume + "ml, Color: RGB(" + colorRGB + ")";
    }
}


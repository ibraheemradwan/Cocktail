/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cocktail;
import java.util.Scanner;
/**
 *
 * @author ibrah
 */


public class Cocktail {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Enter Blender capacity:");
            float capacity = Float.parseFloat(scanner.nextLine());
            Blender blender = new Blender(capacity);

            System.out.println("Add ingredients (name calories volume colorRGB) or type 'blend' to blend:");
            while (scanner.hasNextLine()) {
                String input = scanner.nextLine();
                if ("blend".equals(input)) {
                    blender.blend();
                    break;
                }
                String[] parts = input.split(" ");
                Ingredients ingredient = new Ingredients(parts[0], Integer.parseInt(parts[1]), Float.parseFloat(parts[2]), parts[3]);
                blender.addIngredient(ingredient);
                System.out.println(blender.getInfo());
            }

            System.out.println("Enter Cup capacity:");
            Cup cup = new Cup(Float.parseFloat(scanner.nextLine()));
            String result = blender.pour(cup);
            System.out.println(result);
            System.out.println(cup.getInfo());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cocktail;

/**
 *
 * @author ibrah
 */
public class Milk extends Ingredients{
    private float volume;
    private Color color;

    public Milk(String name, int calories, float volume, String colorRGB) {
        super(name,calories,volume,colorRGB);
        this.volume = volume;
        
    
}

    
    public String toString() {
        return "Milk{" + "volume=" + volume + ", colorRGB=" + color + '}';
    }
    
}
